﻿/* ==========================================================================
   모건홈케어 대화형 스크립트 (main.js)
   ========================================================================== */

document.addEventListener('DOMContentLoaded', () => {

  /* ----------------------------------------------------
   1. 모바일 사이드 네비게이션 제어
   ---------------------------------------------------- */
  const mobileToggle = document.querySelector('.mobile-toggle');
  const mobileClose = document.querySelector('.mobile-close');
  const mobileNav = document.querySelector('.mobile-nav');
  const mobileNavItems = document.querySelectorAll('.mobile-nav-item');

  // 모바일 메뉴 뒤 배경 오버레이 생성
  const mobileOverlay = document.createElement('div');
  mobileOverlay.className = 'mobile-overlay';
  document.body.appendChild(mobileOverlay);

  function openMobileNav() {
    mobileNav.classList.add('open');
    mobileOverlay.classList.add('active');
    document.body.style.overflow = 'hidden';
  }

  function closeMobileNav() {
    mobileNav.classList.remove('open');
    mobileOverlay.classList.remove('active');
    document.body.style.overflow = '';
  }

  // 사이드 메뉴 열기
  if (mobileToggle && mobileNav) {
    mobileToggle.addEventListener('click', openMobileNav);
  }

  // 사이드 메뉴 닫기
  if (mobileClose && mobileNav) {
    mobileClose.addEventListener('click', closeMobileNav);
  }

  // 오버레이 클릭 시 닫기
  mobileOverlay.addEventListener('click', closeMobileNav);

  // 모바일 메뉴 항목 클릭 시 메뉴 닫기 (자동 스크롤 이동 후 닫힘)
  mobileNavItems.forEach(item => {
    item.addEventListener('click', closeMobileNav);
  });


  /* ----------------------------------------------------
   2. 실시간 견적 계산기 로직
   ---------------------------------------------------- */
  const calcItems = document.querySelectorAll('.calc-item');
  const liveTotalDisplay = document.getElementById('liveTotal');
  
  // 가격 서식 변환 함수 (예: 120000 -> 120,000)
  function formatPrice(number) {
    return number.toLocaleString('ko-KR');
  }

  // 전체 금액 계산기
  function calculateTotal() {
    let total = 0;
    
    calcItems.forEach(item => {
      const price = parseInt(item.getAttribute('data-price'), 10) || 0;
      const qtyElement = item.querySelector('.qty-value');
      const qty = parseInt(qtyElement.textContent, 10) || 0;
      
      total += price * qty;
    });
    
    if (liveTotalDisplay) {
      liveTotalDisplay.textContent = formatPrice(total);
    }
    return total;
  }

  // 수량 증감 버튼 이벤트 바인딩
  calcItems.forEach(item => {
    const btnMinus = item.querySelector('.btn-minus');
    const btnPlus = item.querySelector('.btn-plus');
    const qtyValue = item.querySelector('.qty-value');

    if (btnMinus && btnPlus && qtyValue) {
      // 수량 감소
      btnMinus.addEventListener('click', () => {
        let currentQty = parseInt(qtyValue.textContent, 10) || 0;
        if (currentQty > 0) {
          qtyValue.textContent = currentQty - 1;
          calculateTotal();
        }
      });

      // 수량 증가
      btnPlus.addEventListener('click', () => {
        let currentQty = parseInt(qtyValue.textContent, 10) || 0;
        qtyValue.textContent = currentQty + 1;
        calculateTotal();
      });
    }
  });


  /* ----------------------------------------------------
   3. 실제 시공 갤러리 라이트박스 모달
   ---------------------------------------------------- */
  const galleryItems = document.querySelectorAll('.gallery-item');
  const lightboxModal = document.getElementById('lightboxModal');
  const lightboxImg = document.getElementById('lightboxImg');
  const lightboxCaption = document.getElementById('lightboxCaption');
  const lightboxClose = document.getElementById('lightboxClose');
  const lightboxPrev = document.getElementById('lightboxPrev');
  const lightboxNext = document.getElementById('lightboxNext');
  
  let currentImgIndex = 0;
  const galleryData = [];

  // 갤러리 데이터 초기 배열 세팅
  galleryItems.forEach((item, index) => {
    const img = item.querySelector('.gallery-img');
    const caption = item.getAttribute('data-caption') || '모건홈케어 실제 현장';
    galleryData.push({
      src: img.src,
      caption: caption
    });

    // 클릭 시 모달 열기
    item.addEventListener('click', () => {
      currentImgIndex = index;
      openLightbox();
    });
  });

  function openLightbox() {
    if (lightboxModal && lightboxImg && lightboxCaption) {
      const data = galleryData[currentImgIndex];
      lightboxImg.src = data.src;
      lightboxCaption.textContent = data.caption;
      lightboxModal.classList.add('open');
      document.body.style.overflow = 'hidden'; // 스크롤 차단
    }
  }

  function closeLightbox() {
    if (lightboxModal) {
      lightboxModal.classList.remove('open');
      document.body.style.overflow = ''; // 스크롤 복원
    }
  }

  function showNextImage() {
    currentImgIndex = (currentImgIndex + 1) % galleryData.length;
    updateLightboxContent();
  }

  function showPrevImage() {
    currentImgIndex = (currentImgIndex - 1 + galleryData.length) % galleryData.length;
    updateLightboxContent();
  }

  function updateLightboxContent() {
    if (lightboxImg && lightboxCaption) {
      const data = galleryData[currentImgIndex];
      lightboxImg.src = data.src;
      lightboxCaption.textContent = data.caption;
    }
  }

  // 이벤트 바인딩
  if (lightboxClose) {
    lightboxClose.addEventListener('click', closeLightbox);
  }

  if (lightboxNext) {
    lightboxNext.addEventListener('click', (e) => {
      e.stopPropagation();
      showNextImage();
    });
  }

  if (lightboxPrev) {
    lightboxPrev.addEventListener('click', (e) => {
      e.stopPropagation();
      showPrevImage();
    });
  }

  // 모달 배경 클릭 시 닫기
  if (lightboxModal) {
    lightboxModal.addEventListener('click', (e) => {
      if (e.target === lightboxModal) {
        closeLightbox();
      }
    });
  }

  // 키보드 네비게이션 추가 (좌우 화살표, ESC)
  document.addEventListener('keydown', (e) => {
    if (lightboxModal && lightboxModal.classList.contains('open')) {
      if (e.key === 'Escape') {
        closeLightbox();
      } else if (e.key === 'ArrowRight') {
        showNextImage();
      } else if (e.key === 'ArrowLeft') {
        showPrevImage();
      }
    }
  });

  // 모바일 터치 스와이프 지원 (갤러리 사진 좌우 스와이프)
  if (lightboxModal) {
    let touchStartX = 0;
    let touchEndX = 0;

    lightboxModal.addEventListener('touchstart', (e) => {
      touchStartX = e.changedTouches[0].screenX;
    }, { passive: true });

    lightboxModal.addEventListener('touchend', (e) => {
      touchEndX = e.changedTouches[0].screenX;
      const swipeDiff = touchStartX - touchEndX;
      if (Math.abs(swipeDiff) > 50) { // 50px 이상 스와이프 시 인식
        if (swipeDiff > 0) {
          showNextImage(); // 왼쪽으로 스와이프 → 다음 사진
        } else {
          showPrevImage(); // 오른쪽으로 스와이프 → 이전 사진
        }
      }
    }, { passive: true });
  }


  /* ----------------------------------------------------
   4. 견적 전송 및 문자 메시지/상담 예약 접수 로직
   ---------------------------------------------------- */
  const submitBtn = document.getElementById('submitBooking');
  const successModal = document.getElementById('successModal');
  const closeSuccessBtn = document.getElementById('closeSuccess');
  const successMessage = document.getElementById('successMessage');

  if (submitBtn) {
    submitBtn.addEventListener('click', () => {
      const name = document.getElementById('userName').value.trim();
      const phone = document.getElementById('userPhone').value.trim();
      const address = document.getElementById('userAddress').value.trim();
      
      // 1. 고객 필수 입력 정보 검증
      if (!name) {
        alert('예약자 성함을 입력해주세요.');
        document.getElementById('userName').focus();
        return;
      }
      if (!phone) {
        alert('연락처를 입력해주세요.');
        document.getElementById('userPhone').focus();
        return;
      }
      if (!address) {
        alert('시공받으실 주소를 입력해주세요.');
        document.getElementById('userAddress').focus();
        return;
      }

      // 2. 선택한 청소 품목 정리
      let selectedServices = [];
      calcItems.forEach(item => {
        const name = item.getAttribute('data-name');
        const qtyElement = item.querySelector('.qty-value');
        const qty = parseInt(qtyElement.textContent, 10) || 0;
        
        if (qty > 0) {
          selectedServices.push(`${name}: ${qty}대/건`);
        }
      });

      const totalCost = calculateTotal();

      if (selectedServices.length === 0 && totalCost === 0) {
        alert('최소 1개 이상의 시공 품목 수량을 선택해주세요.');
        return;
      }

      // 3. 전송용 문자 템플릿 생성
      const messageLines = [
        `[모건홈케어 견적/예약 문의]`,
        `이름: ${name}`,
        `연락처: ${phone}`,
        `주소: ${address}`,
        `--------------------`,
        `신청 품목:`,
        ...selectedServices,
        `--------------------`,
        `예상 견적가: ${formatPrice(totalCost)}원`,
        `* 후기 작성 약속 시 5,000원 추가 현장 할인 대상`
      ];
      
      const messageText = messageLines.join('\n');

      // 4. 모바일 디바이스 식별 및 SMS 메시지 링크 연동
      const isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent) && !window.MSStream;
      const separator = isIOS ? '&' : '?';
      const smsNumber = '010-2373-1536'; // 모건홈케어 가상 번호
      const smsUrl = `sms:${smsNumber}${separator}body=${encodeURIComponent(messageText)}`;

      // 성공 모달 활성화 및 내용 안내
      if (successModal && successMessage) {
        successMessage.innerHTML = `
          <strong>${name}</strong> 고객님, 실시간 견적 접수가 준비되었습니다.<br><br>
          예상 시공 비용: <strong>${formatPrice(totalCost)}원</strong><br>
          <span style="font-size: 0.85rem; color: #64748b;">(확인 버튼을 누르시면 시공 담당자에게 문자 메시지를 즉시 전송할 수 있는 창으로 연결됩니다.)</span>
        `;
        successModal.classList.add('open');
      }

      // 확인 버튼 누르면 실제 문자 발송 페이지 연결
      if (closeSuccessBtn) {
        // 기존 리스너 누적 방지를 위해 원타임 리스너 설정
        closeSuccessBtn.onclick = () => {
          successModal.classList.remove('remove');
          successModal.classList.remove('open');
          window.open(smsUrl, '_blank');
        };
      }
    });
  }

  // 성공 모달 확인 버튼으로 단순 닫기 대응
  if (closeSuccessBtn && !closeSuccessBtn.onclick) {
    closeSuccessBtn.addEventListener('click', () => {
      if (successModal) {
        successModal.classList.remove('open');
      }
    });
  }


  /* ----------------------------------------------------
   5. 스크롤 페이드인 효과 (Scroll Reveal)
   ---------------------------------------------------- */
  const revealElements = document.querySelectorAll('.service-card, .gallery-item, .process-step, .review-card, .metrics-container');

  const elementReveal = () => {
    const windowHeight = window.innerHeight;
    revealElements.forEach(element => {
      const elementTop = element.getBoundingClientRect().top;
      const elementVisible = 100; // 스크롤 시 100px 정도 보이면 나타나도록 설정
      
      if (elementTop < windowHeight - elementVisible) {
        element.style.opacity = '1';
        element.style.transform = 'translateY(0)';
      }
    });
  };

  // 초기 투명도 및 위치 스타일 선언 (CSS에 적합하지만 JS에서도 스크립트 유연성 확보)
  revealElements.forEach(element => {
    element.style.opacity = '0';
    element.style.transform = 'translateY(30px)';
    element.style.transition = 'opacity 0.6s ease-out, transform 0.6s ease-out';
  });

  // 스크롤 이벤트 감지 및 최초 1회 실행
  window.addEventListener('scroll', elementReveal);
  elementReveal(); // 페이지 로드 후 바로 보이는 영역 1회 체크


  /* ----------------------------------------------------
   6. 헤더 스크롤 시 그림자/배경 강화 효과
   ---------------------------------------------------- */
  const header = document.querySelector('.header');

  window.addEventListener('scroll', () => {
    if (window.scrollY > 20) {
      header.style.backgroundColor = 'rgba(255, 255, 255, 0.97)';
      header.style.boxShadow = '0 4px 20px rgba(0, 0, 0, 0.08)';
    } else {
      header.style.backgroundColor = 'rgba(255, 255, 255, 0.85)';
      header.style.boxShadow = '0 4px 20px rgba(0, 0, 0, 0.03)';
    }
  });

});

